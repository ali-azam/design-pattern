﻿using System;
using System.Collections.Generic;
using MiddleLayer;

namespace FactoryCustomer
{
    public static class Factory     //Design pattern 1 :- Simple factory pattern
    {
        private static Dictionary<string, CustomerBase> custs = new Dictionary<string, CustomerBase>();

        /*static Factory()
        {
            custs.Add("Customer", new Customer());
            custs.Add("Lead", new Lead());
        }*/

        public static CustomerBase Create(string TypeCust)
        {
            //Design pattern 3 :- Lazy loading, Eagger loading
            if (custs.Count == 0)
            {
                custs.Add("Customer", new Customer());
                custs.Add("Lead", new Lead());
            }

            //Design pattern 2 :- RIP (Replace If with Polimorphism)

            /*if (TypeCust == "Customer")
            {
                return new Customer();
            }
            else
            {
                return new Lead();
            }*/

            return custs[TypeCust];
        }
    }
}

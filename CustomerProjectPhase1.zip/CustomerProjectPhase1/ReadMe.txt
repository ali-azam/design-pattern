Shivprasad koirala:

Learn C# Design Patterns Step by Step in 8 hours
https://www.youtube.com/watch?v=YDobmucohqk

